import React from 'react';
import './App.css';
import Frame from './components/frame';

function App() {
  return (
    <div className="App">
      
      <Frame></Frame>
    </div>
  );
}

export default App;
