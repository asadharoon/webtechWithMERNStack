import React from 'react';
const Button = (props) => {
  return (
    <input
      type="button"
      className={props.type === 'action' ? 'btn-action' : 'btn-input'}
      onClick={props.handleClick}
      value={props.label}
      id={props.id}
    />
  );
}

export default Button;