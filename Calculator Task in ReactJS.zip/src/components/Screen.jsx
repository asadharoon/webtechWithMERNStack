import React from 'react'; // Import react module
const Screen = (props) => {
  return (
    <div className="screen">
      <input type="text" readOnly value={props.question} id={props.id[0]} placeholder="Input" />
     <br></br> <input type="text" readOnly value={props.answer} id={props.id[1]} placeholder="Output"/>
     
    </div>
  );
}
export default Screen;