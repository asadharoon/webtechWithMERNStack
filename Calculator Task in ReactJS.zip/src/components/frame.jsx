import React from 'react'; // import react module
import Screen from './Screen'; // Import our screen component from this directory
import Button from './button'; // Import our button component from this directory
import './calc.css';
class Frame extends React.Component {
  constructor() {
    super();
    this.state = {
      question: '',
      answer: ''
    }
    this.handleClick = this.handleClick.bind(this);
  }
  render() {
    return (
      <div className="frame">
            <Screen question={this.state.question} answer={this.state.answer} id={['row1','row2']}/>
            <div className="container">
                <table>
                    <tbody>
                <tr>
                    <td><Button label={'C'} handleClick={this.handleClick} type='input' /></td>
                    <td><Button label={'CE'} handleClick={this.handleClick} type='input' /></td>
                    <td><Button label={'/'} handleClick={this.handleClick} type='action' /></td>
                    <td><Button label={'*'} handleClick={this.handleClick} type='action' />
          </td>
                </tr>
                <tr>
                    <td><Button label={'7'} handleClick={this.handleClick} type='input' /></td>
                    <td><Button label={'8'} handleClick={this.handleClick} type='input' /></td>
                    <td><Button label={'9'} handleClick={this.handleClick} type='input' /></td>
                    <td> <Button label={'-'} handleClick={this.handleClick} type='action' /></td>
                </tr>
                <tr>
                    <td> <Button label={'4'} handleClick={this.handleClick} type='input' /></td>
                    <td><Button label={'5'} handleClick={this.handleClick} type='input' /></td>
          
                    <td><Button label={'6'} handleClick={this.handleClick} type='input' /></td>
                    <td rowSpan="2" ><Button id="plus" label={'+'} handleClick={this.handleClick} type='action'/></td>
                </tr>
                <tr>
                    <td><Button label={'1'} handleClick={this.handleClick} type='input' /></td>
                    <td><Button label={'2'} handleClick={this.handleClick} type='input' /></td>
                    <td><Button label={'3'} handleClick={this.handleClick} type='input' /></td>
                    
                </tr>
                <tr>
                    <td colSpan="2" ><Button label={'0'} handleClick={this.handleClick} type='input' id="zero"/></td>
                    <td><Button label={'.'} handleClick={this.handleClick} type='input' /></td>
                    <td><Button label={'='} handleClick={this.handleClick} type='action' /></td>
                        </tr>
                        </tbody>
        </table>
            </div>
            </div>
    );
  }


  handleClick(event){
      var value = event.target.value; 
      
    switch (value) {
      case '=': { 
            var q = this.state.question.toString();
      var answer = eval(q);
        
        this.setState({ answer });
        break;
      }
        case 'C': {
        this.setState({ question:'', answer: '' });
        break;
      }
      case 'CE':{
        var q = this.state.question.toString();
            q=q.substring(0, q.length - 1);
        this.setState({ question:q, answer: '' });
        break;
      }
    
      default: {
       this.setState({ question: this.state.question += value})
        break;
      }
    }
  }
}

export default Frame;